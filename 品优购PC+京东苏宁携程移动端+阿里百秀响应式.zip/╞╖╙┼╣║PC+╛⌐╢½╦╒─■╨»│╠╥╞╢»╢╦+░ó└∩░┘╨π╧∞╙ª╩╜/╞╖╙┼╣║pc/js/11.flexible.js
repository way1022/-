(function flexible(window, document) {
    //获取html根元素
    var docEl = document.documentElement
        //dpr物理像素比
        //当前浏览器物理像素比是多少如果能拿到就显示当前物理像素比如果没有该属性就拿1来看
    var dpr = window.devicePixelRatio || 1

    // adjust body font size//设置body字体大小
    function setBodyFontSize() {
        if (document.body) { //页面中有没有body元素
            //如果页面中有body元素 就设置body的字体大小
            document.body.style.fontSize = (12 * dpr) + 'px'
        } else {
            //如果页面中没有body这个元素 则等着我们页面主要的DOM元素加载完毕再去设置body的字体大小
            document.addEventListener('DOMContentLoaded', setBodyFontSize)
        }
    }
    setBodyFontSize();

    // set 1rem = viewWidth / 10 //设置我们html元素文字大小
    function setRemUnit() {
        var rem = docEl.clientWidth / 10
        docEl.style.fontSize = rem + 'px'
    }

    setRemUnit()

    // reset rem unit on page resize//当我们页面尺寸发生变化的时候，重新设置rem的大小
    window.addEventListener('resize', setRemUnit)
        //pageshow是我们重新加载页面触发的事件
    window.addEventListener('pageshow', function(e) {
        //e.persisted 返回的是true就是说如果这个页面是从缓存取过来的页面也需要重新计算一下REM的大小
        if (e.persisted) {

            setRemUnit()
        }
    })

    // detect 0.5px supports//有些移动端浏览器不支持0.5像素的写法
    if (dpr >= 2) {
        var fakeBody = document.createElement('body')
        var testElement = document.createElement('div')
        testElement.style.border = '.5px solid transparent'
        fakeBody.appendChild(testElement)
        docEl.appendChild(fakeBody)
        if (testElement.offsetHeight === 1) {
            docEl.classList.add('hairlines')
        }
        docEl.removeChild(fakeBody)
    }
}(window, document))