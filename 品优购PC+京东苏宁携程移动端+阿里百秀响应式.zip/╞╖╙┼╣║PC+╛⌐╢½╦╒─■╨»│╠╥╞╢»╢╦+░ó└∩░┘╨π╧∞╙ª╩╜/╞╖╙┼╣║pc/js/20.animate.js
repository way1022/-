function animate(obj, target, callback) {
    // console.log(callback); //callback = ƒ () {} 调用callback();

    //避免使用var 解决空间提高效率(完美写法)
    //不断点击按钮 这个元素速度会越来越快 因为开启了太多定时器 解决方案 就是让我们元素只有一个定时器
    clearInterval(obj.timer); //先清除原先的定时器只保留一个
    obj.timer = setInterval(function() {
        //把步长值改为整数 不要出现小数的问题
        // var step = Math.ceil((target - obj.offsetLeft) / 10);
        var step = (target - obj.offsetLeft) / 10;
        // 大于0向上取 小于零向下取
        step = step > 0 ? Math.ceil(step) : Math.floor(step);
        if (obj.offsetLeft == target) {
            clearInterval(obj.timer);
            //回调函数写到定时器结束里面
            if (callback) { // 是否有callback回调函数传进来
                //调用函数
                callback();
            }
        }
        //把每次加1的步长值改为一个慢慢变小的值 步长值=（目标值-现在的位置）/10
        obj.style.left = obj.offsetLeft + step + 'px';
    }, 50)
}