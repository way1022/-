 //电梯导航

 $(function() {
     var flag = true; //节流阀

     var boxtop = $(".recom-hd").offset().top;
     fixedscroll(); //页面刷新的时候调用一次函数 防止刷新时候 电梯导航消失

     function fixedscroll() {
         if ($(document).scrollTop() >= boxtop) {
             $(".fixed").fadeIn();
         } else {
             $(".fixed").fadeOut();

         }
     }
     //页面滚动事件
     $(window).scroll(function() {
         fixedscroll(); //页面滚动的时候 调用一次，让电梯导航出来
         if (flag) {
             //页面滚动到当前内容， 就让当前li添加current类
             $(".floor .w h3").each(function(i, ele) {
                 if ($(document).scrollTop() >= $(ele).offset().top) {
                     console.log(i); //获得当前li的索引号
                     $(".fixed li").eq(i).addClass("current").siblings().removeClass("current");
                 }
             })
         }
     });

     //点击对应按钮跳转到对应内容区域,点击并获得当前li的索引号，在通过索引号找到对应内容
     $(".fixed li").click(function() {
         flag = false;
         // console.log($(this).index());
         var current = $(".floor .w h3").eq($(this).index()).offset().top;
         //页面滚动
         $("body,html").stop().animate({
             scrollTop: current
         }, function() {
             flag = true;
         });
         //点击li给当前li添加current类，其余类取消current
         $(this).addClass("current").siblings().removeClass("current");
         //bug:当点击li就会触发页面滚动事件 会给所有li添加current类，点击第三个会逐个跳第三个
         //  解决：节流阀

     })
 })