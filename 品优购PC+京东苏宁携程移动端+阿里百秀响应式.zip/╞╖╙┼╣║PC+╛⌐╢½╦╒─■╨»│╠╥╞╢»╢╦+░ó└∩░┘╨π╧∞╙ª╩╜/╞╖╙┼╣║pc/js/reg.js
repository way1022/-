window.onload = function() {
    //1.手机号
    var regtel = /^1[3|4|5|7|8|9]\d{9}$/;
    var tel = document.querySelector('#inp'); //获取手机号表单
    regexp(tel, regtel)
        //2.qq
    var regqq = /^[1-9]\d{4,}$/;
    var qq = document.querySelector('#qq');
    regexp(qq, regqq);
    //3.昵称
    var regnc = /^[\u4e00-\u9fa5]{2,8}$/;
    var nc = document.querySelector('#nc');
    regexp(nc, regnc);
    //4.短信验证码
    var regyzm = /^\d{6}$/;
    var yzm = document.querySelector('#yzm');
    regexp(yzm, regyzm);
    //5.密码
    var regpassword = /^[A-Za-z0-9_-]{6,16}$/;
    var password = document.querySelector('#password');
    regexp(password, regpassword);
    //6.验证密码
    var surepwd = document.querySelector('#surepwd');
    surepwd.addEventListener('blur', function() {
        if (this.value == password.value) {
            this.nextElementSibling.className = 'success';
            this.nextElementSibling.innerHTML = '<i class="success-icon"></i>两次密码输入正确';
        } else {
            this.nextElementSibling.className = 'error';
            this.nextElementSibling.innerHTML = '<i class="error-icon"></i>两次密码输入不相同，请从新输入';
        }
    })

























    //表单验证函数
    function regexp(ele, reg) {
        ele.addEventListener('blur', function() {

            if (reg.test(this.value)) {
                this.nextElementSibling.className = 'success';
                this.nextElementSibling.innerHTML = '<i class="success-icon"></i>恭喜您输入正确';
            } else {
                this.nextElementSibling.className = 'error';
                this.nextElementSibling.innerHTML = '<i class="error-icon"></i>格式不正确，请从新输入';
            }
        })
    }



}