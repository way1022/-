//页面元素加载完毕后再加载js代码
window.addEventListener('load', function() {
    //获取元素
    var focus = document.querySelector('.focus');
    var ul = focus.children[0]; //获取ul
    var ol = focus.children[1]; //获取ol
    //获取图片宽度就是focus宽度
    var w = focus.offsetWidth;
    //2.利用定时器自动轮播图片
    var index = 0;
    var timer = setInterval(function() {
            index++;
            //移动端移动可以使用translate
            //移动距离
            var translatex = -index * w;
            ul.style.transform = 'translateX(' + translatex + 'px)';
            //添加图片过度效果
            ul.style.transition = 'all .3s';
        }, 2000)
        //自动播放功能-无缝滚动
        // 注意：我们判断条件是要等到图片滚动完毕再去判断，就是过度完成后判断
        // 此时需要添加检测过度完成事件transitionend
    ul.addEventListener('transitionend', function() {
            //一共5张图片，运行的时候界面显示第二张图片，第二张图片索引号为0 最左边那张没有索引号
            //如果图片走到了最后一张，索引号为3，此时需要复原到索引号为0的第二张图片
            if (index >= 3) {
                index = 0;
                //图片去掉过度效果 然后移动
                ul.style.transition = 'none';
                //重新从索引号为0的那张图片，从新开始滚动
                var translatex = -index * w;
                ul.style.transform = 'translateX(' + translatex + 'px)';
            } else if (index < 0) {
                //如果索引号小于0说明倒着走，此时索引号等于2

                index = 2;
                ul.style.transition = 'none';
                var translatex = index * w;
                ul.style.transform = 'translateX(' + translatex + 'px)';

            }
            //3.小圆点跟随变化
            //把ol里面的li带有current类名的选出来去掉类名 remove
            ol.querySelector('.current').classList.remove('current');
            //让当前索引号的li 加上current类  add
            ol.children[index].classList.add('current');
        })
        //4.手指滑动轮播图
        //获取手指触摸初始坐标
    var startx = 0;
    var movex = 0;
    var flag = false;
    ul.addEventListener('touchstart', function(e) {
            startx = e.targetTouches[0].pageX;
            //触摸ul的时候，停止定时器
            clearInterval(timer);
        })
        // (手指移动距离)手指移动后的坐标减去手指初始坐标
    ul.addEventListener('touchmove', function(e) {
            movex = e.targetTouches[0].pageX - startx;

            // 盒子移动：盒子初始距离+手指移动距离
            var translatex = -index * w + movex;
            // 手指拖动的时候，不需要动画效果，所以要取消过度效果
            ul.style.transition = 'none';
            ul.style.transform = 'translate(' + translatex + 'px)';
            flag = true; //如果用户手指移动过我们再做判断
            e.preventDefault(); //阻止滚动屏幕的行为
        })
        //手指离开根据移动距离去判断是回弹还是播放上一张下一张
    ul.addEventListener('touchend', function(e) {
        if (flag) {
            //如果移动距离大于50像素我们就播放上一张或者下一张
            if (Math.abs(movex) > 50) {
                //如果是右滑就是播放上一张 movex是正值
                if (movex > 0) {
                    index--;
                    //如果是左滑就是播放下一张 movex是负值
                } else {
                    index++;
                }
                var translatex = -index * w;
                ul.style.transition = 'all .5s';
                ul.style.transform = 'translate(' + translatex + 'px)';
            } else {
                //移动距离小于50像素
                var translatex = -index * w;
                ul.style.transition = 'all .5s';
                ul.style.transform = 'translate(' + translatex + 'px)';
            }
        }
        // 手指离开时候重新开启定时器 开启前先清除上一个定时器
        clearInterval(timer);
        timer = setInterval(function() {
            index++;
            //移动端移动可以使用translate
            //移动距离
            var translatex = -index * w;
            ul.style.transform = 'translateX(' + translatex + 'px)';
            //添加图片过度效果
            ul.style.transition = 'all .3s';
        }, 2000)
    })




    //返回顶部
    var goback = document.querySelector('.goback');
    var nav = document.querySelector('nav');
    window.addEventListener('scroll', function() {
        if (window.pageYOffset >= nav.offsetTop) {
            goback.style.display = 'block';
        } else {
            goback.style.display = 'none';

        }
    })
    goback.addEventListener('click', function() {
        //点击按钮 迅速返回顶部
        window.scroll(0, 0);
    })


})